"""Isolated fetch regression fixtures."""
