"""Isolated core regression fixtures."""
