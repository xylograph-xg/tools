# OLED 行间公式整理

本项目处理已准入 OLED 文献的完整 PDF 页面。它把多篇论文的页图与文字坐标打成 ZIP，当前通过 Codex Web GPT 临时聊天转录行间公式，默认 GPT-6.2 Sol Extra High，支持 High 回退和 Pro 可用性检查，按篇保存公式、代码与可回查的原文路径。单篇论文可以跨多个批次，覆盖范围见结果的 `pages_checked`。

## 在哪里查看结果

在任务面板的“公式整理”行查看 Codex Web GPT 的活动回合、批次进度和结果目录。数据根目录由 `infrastructure/data/formula-only-control.json` 的 `folder` 指定。以下路径相对于该数据根目录。

| 文件 | 用途 |
| --- | --- |
| `display-equations/by-paper/<paper_id>.json` | 按篇查看原文路径、原文哈希、已检查页、公式和待复核项 |
| `display-equations/batches/<六位批次号>/batch.zip` | 重看实际发送的页图、布局与清单 |
| 同批次的 `attempt.json`、`response.txt` | 核对实际模型、提交回执与网页原回答 |
| 同批次的 `formulas.jsonl`、`equations/` | 逐行读取公式记录，对照原图裁切。Python 表达式仅在可转写时提供 |
| `display-equations/queue.sqlite3`、同目录的 `status.json` 和 `window-observation.json` | 持久队列、后台状态与最近一次网页观测 |

## 运行入口

在工作区根目录使用项目的网页 Python 环境。查看命令帮助可运行 `infrastructure/environments/web/bin/python -m oled_formulas --help`。面板的“启动”和“暂停”分别对应 `python -m oled_formulas start` 和 `python -m oled_formulas pause`。启动请求交给原有的 web-cards 服务执行。

生产服务持有共享锁时通过 `oled_formulas.api.run(config)` 接续登记队列。公开的 `enabled(config)` 检查启用状态和原任务的暂停记录，`control_pilot(config, start)` 提交启停。每小时的 Codex 巡检读取同一队列和回执。

## 源码与测试

| 文件 | 职责 |
| --- | --- |
| [display_equations.py](display_equations.py) | 安排整篇逐页扫描，构建带布局的图片包，定位并裁切独立公式，同页连续裁切复用文字布局和已解码页图 |
| [formula_queue.py](formula_queue.py) | 维护批次、冻结输入和待收回答，按批次索引检查已有输出，按篇汇总结果 |
| [formula_pilot.py](formula_pilot.py) | 检查临时聊天与模型，上传、提交、收取并解析逐式 JSONL |
| [formula_dispatch.py](formula_dispatch.py) | 在唯一所有者连接上分配已登记标签页、观察状态并处理 High 设置 |
| [formula_reload.py](formula_reload.py) | 核对已归档的原回答，恢复反复卡在加载中的页面 |
| [formula_only.py](formula_only.py) | 校验启停条件、原文和授权范围，选择已登记的试测或生产模式 |
| [api.py](api.py)、[__main__.py](__main__.py)、[__init__.py](__init__.py) | Python 公开接口、命令行入口和包标识 |
| [interface.json](interface.json)、[pyproject.toml](pyproject.toml) | 公开合同、构建配置和依赖 |
| [tests/test_display_equations.py](tests/test_display_equations.py) | 行间与行内区分、区域和裁切回归 |
| [tests/test_project_entry.py](tests/test_project_entry.py) | 检查原所有者、面板兼容入口和新项目指向同一份实现 |
| [tests/test_formula_only.py](tests/test_formula_only.py)、[tests/__init__.py](tests/__init__.py) | 公式流程、并行、旧回执、归档和结果合并回归及测试包标识 |

在工作区根目录可单独运行本项目测试。

```sh
PYTHONPATH="$PWD/infrastructure/bootstrap:$PWD:$PWD/../chatgpt_playwright" \
  infrastructure/environments/test/bin/python -m maintenance.test_runner --project oled_formulas
```

共享浏览器服务、任务面板和已冻结的历史试验分别见[浏览器组件](../infrastructure/browser/README.md)、[任务面板](../workbench/desktop_widget/README.md)与[首轮扫描报告](../reports/20261125-oled-corpus/report.md)。

## 处理与恢复细节

`formula_only.py` 在原服务独占锁内整理冻结的 OLED 图片包，复用专用 Chrome、登记槽、模型检查与单 ZIP 提交。仅全部原暂停指纹匹配且独立控制启用时运行。批次账本区分发送意图、正式会话、稳定原文和已合并；非完整结构留原始回执。每篇 JSON 的 source_path 与 source_sha256 指向本地原件。回归位于 `tests/test_formula_only.py`。

`formula_pilot.py` 是原公式所有者的单包临时聊天试测。它先以专窗证据复核登录，再核对临时模式、实际模型和 High、两个原件哈希及图片清单。一份 ZIP 返回逐式 JSONL；保留原回执及本地源文件路径。发送意图存在时阻止重复提交，试测结束后不领取批量任务。

已登记临时聊天公式测试由面板调用 `python -m oled_formulas start|pause`。开启时校验原暂停指纹、测试包与回执，唤起原 web-cards 所有者。暂停写入公式自己的控制记录。

公式测试的重试先检查专用 Chrome 实际连接。启动记录已就绪但连接已关闭时，原服务核对进程与未发送登记，经两次间隔 30 秒的检查后恢复启动。用户已声明登录时可进入原账户复核，实际页面通过后才可上传。

公式试包先在原空白页选定模型，进入临时聊天后再次核对实际模型与 High。网页回执按原 target、单一用户轮次内完整提示和包指纹收取，上传控件产生的附件标签不参与提示匹配。已有发送意图时，重试只收取原回答。逐式 JSONL 与按篇 JSON 均保存原文路径。

[formula_queue.py](formula_queue.py) 将已准备材料的裁图登记到独立自动队列，优先手选根种子，每批最多四篇、每篇六张。队列在原所有者连接上调用临时聊天流程，记录非公式裁图、原回答、逐式 JSONL 与累计单篇文件。

[display_equations.py](display_equations.py) 按已核对原件逐页生成与文字层对齐的完整 JPEG。行间公式回执绑定页码、版式行号及区域，原图重新裁出公式、分式与印刷编号；无法定位归入待核对。新版 display-equations 单独排队、保存单篇结果和原始回执。

行间公式队列接受换行或直接相连的完整 JSON 对象。原包、原回答及原文指纹一致时，原先因对象粘连而待核对的批次在本地重新解析。裁图留白受相邻行位置约束。小字号文字层与 LaTeX 的字母串不符时标记 needs_review，未通过科学核验的结果保留 scientific_verified=false。单篇文件的 review_items 汇集位置不定、不可读及转录存疑的记录。已提交批次短时未得到完整回答时保留原槽位，其他空闲页可以继续，五分钟后只回原页收取。
裁图 v2 从完整页面像素补齐左、右边缘被截断的笔画。重算既有结果前校验已存回答、原包及原文，旧图片保留。原件指纹、文献、页码、式号和原 LaTeX 全部一致的 transcription-reviews 可校正单篇结果，单独保留原转录；原 Python 表达式需重新核验。
公式队列再次领取已返回空白首页的槽位时，允许用该槽旧公式批次的原页、临时会话、任务号及完整回答哈希核实归属，并重新检查实时空白首页。曾经用过的页面不改标为从未提交。等待可复用页时的批数以退回待排后的账本为准。
公式模式支持已登记槽位的空白临时首页。上传前逐项核对实时草稿、附件、原回执及当前模型。可编辑的思考强度由原页切到 High 并重新读取，仅显示强度而无法确认模型的页面在上传前让出本批。收取超时保存原页是否仍生成、是否明确停止与回答元素数，便于区分等待和页面异常。
公式专窗巡检记录主内容区域可见图片、加载失败数及简短图片错误提示。收取回答时同一原页存在图片提示的结果在单篇 review_items 标出，包括无公式判断。原包可解码和网页视觉可用性分别取证。新批在提交后短时收取，仍生成则保留原槽、约 45 秒后再核对；已结束但无正文的原页维持较慢复核。
行间公式所有者全窗检查时将逐页观测另行原子写入 display-equations/window-observation.json。它记录窗口、所有者、时间及各原 target 的占用、活动和图片提示；任务面板只读取该摘要。

[formula_reload.py](formula_reload.py) 在账户复核期间处理卡在加载中的已归档公式页。原所有者两次检查间隔至少一个巡检周期，并核对固定槽位、原回答及批次指纹后，在同页重新打开原地址。每个已归档请求和地址只登记一次导航。

[formula_dispatch.py](formula_dispatch.py) 在同一公式所有者连接上为 OLED 行间公式分发批次，最多五个操作同时进行，已提交的回答可继续在其余专用标签页生成。批次和标签页独占，最终点击仍使用共享提交锁。未通过模型核对的空页暂缓使用，已发送回执在原页收取；所有者定期刷新专窗观测。

公式专窗记录的登录或验证阻塞由原所有者持续检查。只有登记中的 20 页已登录、验证提示均已消失且至少间隔 30 秒重复确认，才恢复新派发。网页回答开头可能带有代码块的 JSONL 语言名，恢复解析时保留原文并核对冻结包、原文版本和逐页覆盖。

公式窗口观测同时记录 document.readyState、浏览器导航类型、文档起始时间、Chrome 的回收后重载标记和浏览器错误页信息，供面板说明点击标签后的加载现象。

公式所有者读取原生输入框强度按钮的当前值。空白输入框的强度设置独立于派发开关。登记的专窗因旧登录提示等待整窗复核时，本轮所有页均未观察到登录、验证或额度提示，原所有者可以在已登录的合格空白页上仅调节思考强度并回读按钮。已核实发送前终止且仍在保留的材料允许调整空白页的强度，回执、队列及发送许可保持原状；实际批次在共享发送锁内再次核对 GPT-6.2 与 High，回执记录该次核对结果。

发送前已终止的批次可保留回执并释放空白槽位。原所有者在提交锁内核对原已保存回答、当前批次 ZIP 和上传准备回执，逐项检查实时输入框与其他待收任务，并在批次目录保存 `unsent-slot-release.json`。批次进入待核对，释放槽位单独记录。

[formula_results.py](formula_results.py) 核对已收取回执、冻结 ZIP、排队页和 PDF 指纹。单篇 JSON 的 expected_pages、pages_checked、missing_pages 和 complete 表示计划页覆盖，source_batches 给出批号及回执指纹。failed_batches_at_export 是生成该文件时的异常批号。scientific_verified 单独保留。Python 标量语法通过时 python_status 为 scalar_syntax_checked；不合规表达式保存在 rejected_python_rhs，python_rhs 留空，并进入 review_items。原回答和原逐式回执保留。启动时补齐历史单篇标识；publishing 表示正在本地发布，意外退出后原所有者从同一已保存回答接续。

原页两次间隔至少 30 秒确认终态且无正文时，批次进入 review，原页与原回执保留，empty-answer-observations.json 记录两次观察。原页有完整回答但归档中断的历史批次或试测，须核对正式会话、实际回答和用户提示后才能恢复 ready。

[报告问题回归测试](tests/test_report_regressions.py) 覆盖单篇缺页、版本变化、发布中断接续、标量表达式与两轮空回答复核。

上传等待使用工作区现有的 upload_settle_timeout_seconds。终态空正文判断沿用原页唯一提示验证，空输入框的排版换行按空白处理。公式提示同步写明标量表达式约束；历史原回答原样保存。

已完成的登记公式页回到空白首页后，formula_reload.py 复核原回执并在同一文档间隔 30 秒观察两次，提交锁内再次核对后在 completed-home-recovery 留存证据。原配额、暂停和身份保护继续生效。最近约五分钟的逐页状态保存在 observation-history。模型名称仍需页面控件给出确证；只看到强度的临时页面可短暂等待页面加载并重新读取。编号公式位置与模型框分离时，只有唯一印刷式号和完整文字行能共同确定区域才允许重新裁图，并标为待核。

原会话已停止且存在正文时单独保存中断文本供复核。终态空正文在原请求身份仍匹配时留存脱敏的回答节点、可见文本和文本内容。不同版本的裁图保留各自文件。

[attachment_gate.py](attachment_gate.py) 仅限制新的公式上传。五分钟内两个不同登记槽的发送前附件入口失败，或一个明确附件限额错误，会写入持久冷却。等待至少十五分钟后，只在可用原槽查看附件控件。至多放行一个正常待发批，收到本批本页提交回执才恢复并行。原已发请求仍在原页收取。对应回归见 [test_attachment_gate.py](tests/test_attachment_gate.py)。

待发整批按文献首次入队的批号分组，同组按原批号领取，先收取已发送会话，保留手选种子原计划的顺序。全部原定页（包括首页与长文后段）保持在冻结计划。历史槽位冲突只在旧失败有逐项吻合的未发送释放归档、或旧回答已完整落盘并核对指纹时解除。


[entry_retry.py](entry_retry.py) 复核附件失败批的归档和上传事件。试探批获得较晚的正式提交回执后，若原批次只有一次上传开始、一次入口失败，且页面、所有者、材料与归档一致，原所有者可将它重新排队一次。原提示和 ZIP 继续使用，原回执保存在批次的 entry-retry 目录。队列中的唯一记录使重启和第二次失败都不能再次获得重试。

恢复探测与发送前检查共用浏览器的文档附件判定。看到照片、相机、灰色菜单或额度提示时继续冷却。状态文件记录实际探测的页面、结果、可候选槽数和下一次检查时间。相同运行状态最多每五秒刷新一次。后台退出原因保存在主工作目录的 formula-owner-exit.json。

网页版运行依赖同级 chatgpt_playwright 中的 web_gpt 和 Playwright 1.63.0。可用 WEB_GPT_IMPORT_ROOT 指定现有工具位置。上传日志保存上传工具实际指纹。新的整页提示要求判空回答带页面依据，缺少依据的条目进入待核对。

[scope.py](scope.py) 核对标题和摘要中的 OLED 术语。仅由 cooled、pooled 等普通词误入的文献进入范围复核。新的混合批在冻结前将这些文献的页移入单独待核对批，原有合格页继续处理。冻结材料在外发前复核，旧结果可用本次复核的文献清单筛除。

按篇结果的 `export_schema_version=2` 保留原 PDF 路径、批号和冻结回答来源。`formulas` 用于查询全部提取记录，`training_candidates` 提供标题有 OLED 器件依据且通过基础转录筛查的待核对公式。`training_formulas` 仅用于训练。现有流程没有逐式科学验收回执，因此该数组为空。图片告警在回答保存后仍可按槽位、会话、任务和 ZIP 指纹回写。后台重新发布受影响的单篇文件，成功写完全部文件才登记该告警。印刷式号只有与原文位置和编号吻合时才从缺失词检查中排除。

附件冷却探测在原专窗的干净临时首页展开原生附件菜单，检查后复原菜单。单批提交结果不明且已隔离时，保留原批并重新进入冷却。原临时会话连续半小时观测无正文节点时归档页面并转待复核，原页随后出现回答会自动接回收取。

[audit-review-items.json](audit-review-items.json) 登记审计中定位到原页的疑点。单篇发布时同时核对原文、回答、页码、式号和 LaTeX 指纹，命中项进入待复核，保留原转录。候选清单只显示 LaTeX 和原页证据。完整公式的 python_mapping_issues 列出赋值目标、等号或角度依据缺口。

独立科学核验可在 training-reviews/文章ID.json 提供 oled-scientific-review-v1 回执，记录 reviewer、topic_verified、topic_evidence、source_sha256 及逐式 items。每项需有 paper_id、batch、pdf_page、latex_sha256、raw_sha256、crop_sha256、page_evidence，且 display_verified、latex_verified、scientific_verified 全部通过。后台启动或该文章重新发布时按当前回执核对；同项冲突或任一指纹变化即排除。训练数组当前仅接收已核验 LaTeX。

临时首页的上传操作也可能以原生按钮、标签或文档输入框呈现。附件菜单已展开、页面归属稳定且复查确认输入框支持 ZIP 时，可放行一个正式待发批。检查到附件限制、禁用操作或不确定提交时仍沿用冷却与原回执保护。

[slot_recovery.py](slot_recovery.py) 由专窗后台恢复异常批次。独立核对冻结包、原槽回执及同页稳定观测，把网页、截图和原状态保存到该批的 slot-recovery。已发送会话只可在原槽按原地址读取一次。中断正文与原页逐字一致且完整覆盖清单时保留中断标记，并逐条进入复核。未发送草稿和附件只在提示、带 SHA256 的文件名、原上传事件及槽位归属全部吻合时清理。对应回归见 [test_slot_recovery.py](tests/test_slot_recovery.py)。

[unavailable_slots.py](unavailable_slots.py) 处理本次已确认无法找回的七个原临时会话。[限定清单](unavailable-slot-authorization.json) 绑定原 target、回执、发送时间、原地址、冻结包和归档指纹。后台再次间隔核对同一空白首页，保存前后网页证据后释放原槽。原批次留在待复核队列。

网页在建立上传回执之前因缺少 Chat 菜单或输入框停止时，后台核对冻结包、失败阶段与空上传事件，保存原故障并最多重新准入一次。

已证实未点击发送且已归档并清除原附件的失败批，可凭原上传事件、原页面和空白释放回执进行同一冻结包的单次重试。原回答待复核批不会进入此路径。

[pro_menu.py](pro_menu.py) OLED 新批次先用 GPT-6.2 Sol Extra High，明确该档额度耗尽且未发送时降为 High。每三小时由公式所有者读取一个 App 窗口新鲜的已登录模型菜单。出现可用 Pro 时，下一批最多新增一个优先 Pro 的并行位置，保留已有可用位置；选档失败的位置回到 Extra High。App 每回合核对实际选档。未收取的批次沿用原回执。 到期后遇到没有新鲜菜单的时段，等待下一个活动回合。定时与 Pro 优先位置保存在运行目录的 oled-pro-menu 文件中。回归见 [test_pro_menu.py](tests/test_pro_menu.py)。

[app_queue.py](app_queue.py) 在原公式所有者内领取未尝试外发的批次，已归档且获准重试的未发送失败批次核对上传历史后沿原编号接续，逐批冻结图页并通过 Codex Web GPT 同时处理最多五批。App 正忙而暂时无法重复检查登录时，以同一服务进程和启动器会话最近 60 秒的已确认登录或本队列成功执行回执核对。各批独立收取，空位自动补入；同篇结果依次发布。App 内的账户检查、派发、收取均独立于历史 Chrome 专窗。新批次用 JSONL 代码块保留下划线；对已保存的无式页面回答，可核对冻结材料后本地恢复被 Markdown 转义的结构键。原材料、账户验证、附件冷却和结果发布合同继续执行。按批记录 app-job.json，按篇输出保留在 display-equations/by-paper。回归见 [test_app_queue.py](tests/test_app_queue.py)。

单篇导出版本 3 保留页覆盖 complete，另列 conflict_pages 和 visual_review_pages。同页 non_equation 必须独占，冲突记录进入 review_items，批次进入 review。缺少 layout 的阳性回答仅在有效框与独立数学文字行交叠且通过原裁图守卫时保留带图待核候选。新逐式清单和单篇导出将未证实的赋值、角度、转录或视觉依据对应的代码保存在 unverified_python_rhs，公开 python_rhs 留空。已完成批次的局部重新解析依据冻结原回答与原文指纹，历史逐式清单按指纹归档。
