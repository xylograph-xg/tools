"""Isolated browser regression fixtures."""
