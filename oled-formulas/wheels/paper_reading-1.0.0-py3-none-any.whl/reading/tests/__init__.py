"""Isolated reading regression fixtures."""
