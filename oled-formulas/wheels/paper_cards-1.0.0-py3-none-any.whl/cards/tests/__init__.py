"""Isolated cards regression fixtures."""
