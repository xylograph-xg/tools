"""Isolated maintenance regression fixtures."""
