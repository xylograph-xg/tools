"""Isolated workbench regression fixtures."""
