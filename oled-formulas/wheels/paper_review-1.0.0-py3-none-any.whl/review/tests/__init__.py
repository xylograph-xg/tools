"""Isolated review regression fixtures."""
