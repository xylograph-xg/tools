"""Isolated article regression fixtures."""
